# Calculo_Mental_kids

Practica 2 de la materia Proceso Personal de Software
Programa de calculo mental para niños de primaria.